# pterodactyl-argon

Argon UI theme implementation for Pterodactyl.io.
